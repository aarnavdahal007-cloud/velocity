import AnnouncementBar from "./components/AnnouncementBar";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Products from "./components/Products";
import Lookbook from "./components/Lookbook";
import About from "./components/About";
import Testimonials from "./components/Testimonials";
import Newsletter from "./components/Newsletter";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="bg-black min-h-screen">
      <AnnouncementBar />
      <Navbar />
      <Hero />
      <Features />
      <Products />
      <Lookbook />
      <About />
      <Testimonials />
      <Newsletter />
      <Contact />
      <Footer />
    </div>
  );
}
