import { BRAND } from "../config/siteConfig";

export default function About() {
  return (
    <section id="about" className="bg-[#0a0a0a] py-28 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left — Image collage */}
          <div className="relative">
            <div className="relative z-10">
              <img
                src="https://images.pexels.com/photos/34103221/pexels-photo-34103221.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=550"
                alt="Velocity brand"
                className="w-full max-w-md object-cover"
                style={{ aspectRatio: "3/4" }}
              />
            </div>
            {/* Accent box behind */}
            <div className="absolute top-8 left-8 right-0 bottom-0 border border-red-700/40 z-0" />
            {/* Red accent corner */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-red-700/20 border-l-2 border-t-2 border-red-600" />
            {/* Floating badge */}
            <div className="absolute bottom-10 -right-4 bg-black border border-red-700 px-6 py-5 z-20">
              <p className="font-['Bebas_Neue'] text-4xl text-red-500 leading-none">2025</p>
              <p className="text-gray-400 text-xs font-['Inter'] tracking-widest uppercase mt-1">Est. Year</p>
            </div>
          </div>

          {/* Right — Text */}
          <div>
            <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-6">
              Our Story
            </p>
            <h2 className="font-['Bebas_Neue'] text-[clamp(2.5rem,5vw,5rem)] text-white tracking-wide leading-none mb-8">
              CRAFTED FOR THE<br />
              <span className="text-red-500">FEARLESS</span>
            </h2>

            <div className="space-y-5 mb-10">
              <p className="text-gray-400 font-['Inter'] text-base leading-relaxed">
                {BRAND.description}
              </p>
              <p className="text-gray-400 font-['Inter'] text-base leading-relaxed">
                Every piece in our collection is a statement. We merge the raw energy of street culture with the precision of luxury fashion — no compromises, no shortcuts.
              </p>
              <p className="text-gray-400 font-['Inter'] text-base leading-relaxed">
                At Velocity, we believe clothing isn't just fabric — it's identity. It's the armor you wear when you walk into a room and own it.
              </p>
            </div>

            {/* Values */}
            <div className="grid grid-cols-2 gap-6 mb-10">
              {[
                { label: "Quality First", desc: "Every stitch is inspected before it leaves our studio." },
                { label: "Designed Bold", desc: "No generic silhouettes. Every piece makes a statement." },
                { label: "Built to Last", desc: "Premium materials that age with you, not against you." },
                { label: "Culture-Led", desc: "Influenced by the streets, refined for the world." },
              ].map((val) => (
                <div key={val.label} className="border-l-2 border-red-700 pl-4">
                  <h4 className="text-white font-['Inter'] font-semibold text-sm mb-1">{val.label}</h4>
                  <p className="text-gray-500 text-xs font-['Inter'] leading-relaxed">{val.desc}</p>
                </div>
              ))}
            </div>

            <a
              href="#products"
              className="inline-flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase px-8 py-4 transition-all duration-300"
            >
              Explore Collection
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
