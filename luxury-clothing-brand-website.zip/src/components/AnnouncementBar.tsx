import { ANNOUNCEMENT } from "../config/siteConfig";

export default function AnnouncementBar() {
  return (
    <div className="bg-red-700 text-white overflow-hidden py-2.5">
      <div className="whitespace-nowrap animate-marquee inline-block">
        {[...Array(4)].map((_, i) => (
          <span key={i} className="mx-12 text-xs font-['Inter'] font-medium tracking-widest uppercase">
            {ANNOUNCEMENT.text}
          </span>
        ))}
      </div>
    </div>
  );
}
