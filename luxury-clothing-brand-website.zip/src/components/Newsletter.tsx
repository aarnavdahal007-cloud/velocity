import { useState } from "react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      setEmail("");
    }
  };

  return (
    <section
      className="relative py-28 px-6 overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #1a0000 0%, #0a0a0a 50%, #1a0000 100%)",
      }}
    >
      {/* Decorative */}
      <div className="absolute inset-0 bg-[url('/images/collection-banner.jpg')] bg-cover bg-center opacity-10" />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-black" />
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-700 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-700 to-transparent" />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-6">
          Join The Movement
        </p>
        <h2 className="font-['Bebas_Neue'] text-[clamp(2.5rem,6vw,5rem)] text-white tracking-wide leading-none mb-6">
          GET EARLY ACCESS<br />
          <span className="text-red-500">TO NEW DROPS</span>
        </h2>
        <p className="text-gray-400 font-['Inter'] text-sm leading-relaxed mb-10 max-w-md mx-auto">
          Subscribe to the Velocity newsletter and be first to know about exclusive drops, limited editions, and members-only discounts.
        </p>

        {submitted ? (
          <div className="border border-red-700 bg-red-900/20 px-8 py-6 inline-block">
            <p className="text-red-400 font-['Inter'] font-semibold text-sm tracking-widest uppercase">
              ✓ You're on the list. Welcome to Velocity.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-0 max-w-lg mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
              className="flex-1 bg-black/60 border border-white/20 text-white font-['Inter'] text-sm px-6 py-4 outline-none focus:border-red-600 placeholder:text-gray-600 transition-colors duration-300"
            />
            <button
              type="submit"
              className="bg-red-600 hover:bg-red-700 text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase px-8 py-4 transition-colors duration-300 whitespace-nowrap"
            >
              Subscribe
            </button>
          </form>
        )}

        <p className="text-gray-700 text-xs font-['Inter'] mt-5">
          No spam. Unsubscribe at any time. By subscribing you agree to our Privacy Policy.
        </p>
      </div>
    </section>
  );
}
