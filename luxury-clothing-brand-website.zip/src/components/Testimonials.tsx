import { TESTIMONIALS } from "../config/siteConfig";

export default function Testimonials() {
  return (
    <section className="bg-black py-28 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-4">
            What They Say
          </p>
          <h2 className="font-['Bebas_Neue'] text-[clamp(3rem,7vw,6rem)] text-white tracking-wide leading-none">
            REVIEWS
          </h2>
          <div className="flex items-center justify-center gap-4 mt-4">
            <div className="h-px w-16 bg-red-700" />
            <div className="w-2 h-2 bg-red-600 rotate-45" />
            <div className="h-px w-16 bg-red-700" />
          </div>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-[#0d0d0d] border border-white/5 hover:border-red-800/50 p-8 transition-all duration-500 group relative overflow-hidden"
            >
              {/* Accent */}
              <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-red-700 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {Array(t.rating).fill(0).map((_, i) => (
                  <svg key={i} className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 0 0 .95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 0 0-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 0 0-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 0 0-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 0 0 .951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>

              {/* Quote */}
              <p className="text-gray-300 font-['Inter'] text-sm leading-relaxed mb-8 italic">
                "{t.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-red-700 flex items-center justify-center text-white font-['Inter'] font-bold text-xs">
                  {t.avatar}
                </div>
                <div>
                  <p className="text-white font-['Inter'] font-semibold text-sm">{t.name}</p>
                  <p className="text-gray-600 text-xs font-['Inter']">{t.handle}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 flex flex-wrap justify-center gap-10 border-t border-white/5 pt-14">
          {[
            { num: "10,000+", label: "Happy Customers" },
            { num: "4.9/5", label: "Average Rating" },
            { num: "500+", label: "5-Star Reviews" },
            { num: "100%", label: "Authentic Quality" },
          ].map((badge) => (
            <div key={badge.label} className="text-center">
              <p className="font-['Bebas_Neue'] text-4xl text-red-500 tracking-wide">{badge.num}</p>
              <p className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase mt-1">{badge.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
