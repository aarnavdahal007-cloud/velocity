import { BRAND } from "../config/siteConfig";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-black border-t border-white/5">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand col */}
          <div className="lg:col-span-1">
            <h3 className="font-['Bebas_Neue'] text-4xl text-white tracking-[0.2em] mb-4">
              {BRAND.name}
            </h3>
            <div className="w-12 h-0.5 bg-red-600 mb-6" />
            <p className="text-gray-500 font-['Inter'] text-sm leading-relaxed mb-8">
              {BRAND.description}
            </p>
            {/* Social */}
            <div className="flex gap-4">
              {[
                {
                  label: "Instagram",
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/>
                    </svg>
                  ),
                },
                {
                  label: "X",
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                  ),
                },
                {
                  label: "TikTok",
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34l-.01-8.83a8.18 8.18 0 0 0 4.78 1.52V4.56a4.85 4.85 0 0 1-1-.13z"/>
                    </svg>
                  ),
                },
              ].map((social) => (
                <a
                  key={social.label}
                  href="#"
                  aria-label={social.label}
                  className="w-10 h-10 border border-white/10 flex items-center justify-center text-gray-500 hover:border-red-600 hover:text-red-500 transition-all duration-300"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Shop links */}
          <div>
            <h4 className="text-white font-['Inter'] font-semibold text-sm tracking-widest uppercase mb-6">Shop</h4>
            <div className="w-8 h-px bg-red-700 mb-6" />
            <ul className="space-y-4">
              {["New Arrivals", "Hoodies", "Jackets", "Tops", "Bottoms", "Sets", "Accessories"].map((link) => (
                <li key={link}>
                  <a href="#products" className="text-gray-500 font-['Inter'] text-sm hover:text-red-500 transition-colors duration-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Info links */}
          <div>
            <h4 className="text-white font-['Inter'] font-semibold text-sm tracking-widest uppercase mb-6">Info</h4>
            <div className="w-8 h-px bg-red-700 mb-6" />
            <ul className="space-y-4">
              {["About Us", "Lookbook", "Size Guide", "Shipping Policy", "Return Policy", "Privacy Policy", "Terms of Service"].map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-500 font-['Inter'] text-sm hover:text-red-500 transition-colors duration-300">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter mini */}
          <div>
            <h4 className="text-white font-['Inter'] font-semibold text-sm tracking-widest uppercase mb-6">Newsletter</h4>
            <div className="w-8 h-px bg-red-700 mb-6" />
            <p className="text-gray-500 font-['Inter'] text-sm leading-relaxed mb-6">
              Join the inner circle. Get early access to drops and exclusive offers.
            </p>
            <form onSubmit={(e) => e.preventDefault()} className="space-y-3">
              <input
                type="email"
                placeholder="Your email"
                className="w-full bg-[#0d0d0d] border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3 outline-none transition-colors duration-300 placeholder:text-gray-700"
              />
              <button
                type="submit"
                className="w-full bg-red-700 hover:bg-red-600 text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase py-3 transition-colors duration-300"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/5 px-6 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-700 font-['Inter'] text-xs">
            © {year} {BRAND.name}. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {["Privacy", "Terms", "Cookies"].map((link) => (
              <a key={link} href="#" className="text-gray-700 font-['Inter'] text-xs hover:text-red-500 transition-colors duration-300">
                {link}
              </a>
            ))}
          </div>
          {/* Payment icons */}
          <div className="flex items-center gap-3">
            {["VISA", "MC", "AMEX", "PayPal"].map((pay) => (
              <span key={pay} className="border border-white/10 text-gray-600 font-['Inter'] text-[9px] font-bold tracking-wider px-2 py-1">
                {pay}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
