import { FEATURES } from "../config/siteConfig";

export default function Features() {
  return (
    <section className="bg-black border-y border-red-900/30 py-14">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
        {FEATURES.map((feat) => (
          <div
            key={feat.title}
            className="flex flex-col items-center text-center gap-3 group"
          >
            <span className="text-3xl">{feat.icon}</span>
            <h3 className="text-white font-['Inter'] font-semibold text-sm tracking-widest uppercase group-hover:text-red-500 transition-colors duration-300">
              {feat.title}
            </h3>
            <p className="text-gray-500 text-xs font-['Inter'] leading-relaxed">{feat.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
