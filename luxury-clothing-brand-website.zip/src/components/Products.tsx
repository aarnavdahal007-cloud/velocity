import { useState } from "react";
import { PRODUCTS, CATEGORIES } from "../config/siteConfig";

export default function Products() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [hovered, setHovered] = useState<number | null>(null);

  const filtered =
    activeCategory === "All"
      ? PRODUCTS
      : PRODUCTS.filter((p) => p.category === activeCategory);

  const badgeStyles: Record<string, string> = {
    red: "bg-red-600 text-white",
    gold: "bg-amber-500 text-black",
    default: "bg-white text-black",
  };

  return (
    <section id="products" className="bg-[#0a0a0a] py-28 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-4">
            The Collection
          </p>
          <h2 className="font-['Bebas_Neue'] text-[clamp(3rem,7vw,6rem)] text-white tracking-wide leading-none mb-6">
            SHOP THE LATEST
          </h2>
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="h-px w-16 bg-red-700" />
            <div className="w-2 h-2 bg-red-600 rotate-45" />
            <div className="h-px w-16 bg-red-700" />
          </div>
          <p className="text-gray-400 font-['Inter'] text-sm max-w-xl mx-auto leading-relaxed">
            Precision-crafted pieces for those who demand more. Each item is designed with intention, built to last.
          </p>
        </div>

        {/* Category filter */}
        <div className="flex flex-wrap gap-3 justify-center mb-14">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2.5 text-xs font-['Inter'] font-semibold tracking-widest uppercase transition-all duration-300 border ${
                activeCategory === cat
                  ? "bg-red-600 border-red-600 text-white"
                  : "bg-transparent border-white/20 text-gray-400 hover:border-red-600 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((product) => (
            <div
              key={product.id}
              className="group relative flex flex-col bg-[#111] border border-white/5 hover:border-red-800/60 transition-all duration-500 cursor-pointer"
              onMouseEnter={() => setHovered(product.id)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Image */}
              <div className="relative overflow-hidden aspect-[3/4]">
                <img
                  src={product.image}
                  alt={product.name}
                  className={`w-full h-full object-cover object-top transition-transform duration-700 ${
                    hovered === product.id ? "scale-108" : "scale-100"
                  }`}
                  style={{ transform: hovered === product.id ? "scale(1.06)" : "scale(1)" }}
                />
                {/* Overlay on hover */}
                <div
                  className={`absolute inset-0 bg-black/40 transition-opacity duration-500 ${
                    hovered === product.id ? "opacity-100" : "opacity-0"
                  }`}
                />
                {/* Quick add button */}
                <div
                  className={`absolute bottom-0 left-0 right-0 p-4 transition-all duration-500 ${
                    hovered === product.id ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
                  }`}
                >
                  <button
                    disabled={!product.inStock}
                    className={`w-full py-3 text-xs font-['Inter'] font-semibold tracking-widest uppercase transition-colors duration-300 ${
                      product.inStock
                        ? "bg-red-600 hover:bg-red-700 text-white"
                        : "bg-gray-700 text-gray-500 cursor-not-allowed"
                    }`}
                  >
                    {product.inStock ? "Quick Add to Cart" : "Out of Stock"}
                  </button>
                </div>

                {/* Badge */}
                {product.badge && (
                  <span
                    className={`absolute top-4 left-4 text-[10px] font-['Inter'] font-bold tracking-widest uppercase px-3 py-1 ${
                      badgeStyles[product.badgeColor ?? "default"] ?? badgeStyles.default
                    }`}
                  >
                    {product.badge}
                  </span>
                )}

                {/* Out of stock overlay */}
                {!product.inStock && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="bg-black border border-white/20 text-gray-400 text-xs font-['Inter'] tracking-widest uppercase px-4 py-2">
                      Sold Out
                    </span>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="p-6 flex flex-col flex-1">
                <p className="text-red-600 text-[10px] font-['Inter'] font-semibold tracking-widest uppercase mb-2">
                  {product.category}
                </p>
                <h3 className="text-white font-['Playfair_Display'] text-lg font-bold leading-tight mb-2 group-hover:text-red-400 transition-colors duration-300">
                  {product.name}
                </h3>
                <p className="text-gray-500 text-xs font-['Inter'] leading-relaxed mb-4 flex-1">
                  {product.description}
                </p>

                {/* Sizes */}
                <div className="flex flex-wrap gap-1.5 mb-5">
                  {product.sizes.map((size) => (
                    <span
                      key={size}
                      className="border border-white/15 text-gray-400 text-[9px] font-['Inter'] font-medium tracking-wider px-2 py-1 hover:border-red-600 hover:text-white transition-colors cursor-pointer"
                    >
                      {size}
                    </span>
                  ))}
                </div>

                {/* Price */}
                <div className="flex items-center justify-between">
                  <div className="flex items-baseline gap-2">
                    <span className="text-white font-['Inter'] font-bold text-xl">
                      ${product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-gray-600 font-['Inter'] text-sm line-through">
                        ${product.originalPrice}
                      </span>
                    )}
                  </div>
                  {product.originalPrice && (
                    <span className="text-red-500 text-xs font-['Inter'] font-semibold">
                      Save ${product.originalPrice - product.price}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View all button */}
        <div className="text-center mt-16">
          <button className="border border-red-700 text-red-500 hover:bg-red-600 hover:text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase px-12 py-4 transition-all duration-300">
            View All Products
          </button>
        </div>
      </div>
    </section>
  );
}
