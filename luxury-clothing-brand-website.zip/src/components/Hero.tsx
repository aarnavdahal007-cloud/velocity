import { HERO, BRAND } from "../config/siteConfig";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background: `url(${HERO.backgroundImage}) center/cover no-repeat`,
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/70" />
      {/* Red gradient accent */}
      <div className="absolute inset-0 bg-gradient-to-tr from-red-950/60 via-transparent to-transparent" />
      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-black to-transparent" />

      {/* Decorative lines */}
      <div className="absolute left-10 top-1/4 w-px h-48 bg-gradient-to-b from-transparent via-red-600 to-transparent opacity-60" />
      <div className="absolute right-10 bottom-1/4 w-px h-48 bg-gradient-to-b from-transparent via-red-600 to-transparent opacity-60" />

      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
        {/* Sub label */}
        <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-6 opacity-90">
          {HERO.subheading}
        </p>

        {/* Main heading */}
        <h1 className="font-['Bebas_Neue'] text-[clamp(5rem,16vw,13rem)] leading-none text-white tracking-[0.08em] mb-6 drop-shadow-2xl">
          {HERO.heading.split("\n").map((line, i) => (
            <span key={i} className="block">
              {i === 1 ? (
                <span className="text-red-500">{line}</span>
              ) : (
                line
              )}
            </span>
          ))}
        </h1>

        {/* Tagline */}
        <p className="text-gray-300 font-['Inter'] font-light text-base md:text-lg tracking-[0.3em] uppercase mb-12 max-w-xl mx-auto">
          {BRAND.tagline}
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href={HERO.ctaLink}
            className="group relative inline-flex items-center gap-3 bg-red-600 hover:bg-red-700 text-white font-['Inter'] font-semibold text-sm tracking-widest uppercase px-10 py-4 transition-all duration-300 overflow-hidden"
          >
            <span className="relative z-10">{HERO.ctaText}</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 relative z-10 group-hover:translate-x-1 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
          <a
            href="#lookbook"
            className="inline-flex items-center gap-3 border border-white/40 hover:border-red-500 text-white font-['Inter'] font-medium text-sm tracking-widest uppercase px-10 py-4 transition-all duration-300 hover:bg-red-600/10"
          >
            View Lookbook
          </a>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-3 gap-8 max-w-lg mx-auto border-t border-white/10 pt-10">
          {[
            { num: "50+", label: "Pieces" },
            { num: "10K+", label: "Customers" },
            { num: "4.9★", label: "Rating" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-['Bebas_Neue'] text-3xl text-red-500 tracking-wide">{stat.num}</p>
              <p className="text-gray-400 text-xs font-['Inter'] tracking-widest uppercase mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-60">
        <span className="text-gray-400 text-xs font-['Inter'] tracking-widest uppercase">Scroll</span>
        <div className="w-px h-10 bg-gradient-to-b from-red-500 to-transparent animate-pulse" />
      </div>
    </section>
  );
}
