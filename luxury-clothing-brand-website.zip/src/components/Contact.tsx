import { BRAND } from "../config/siteConfig";

export default function Contact() {
  return (
    <section id="contact" className="bg-[#080808] py-28 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left */}
          <div>
            <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-6">
              Get In Touch
            </p>
            <h2 className="font-['Bebas_Neue'] text-[clamp(2.5rem,5vw,5rem)] text-white tracking-wide leading-none mb-8">
              CONTACT<br />
              <span className="text-red-500">VELOCITY</span>
            </h2>
            <p className="text-gray-400 font-['Inter'] text-base leading-relaxed mb-10">
              For wholesale inquiries, collaborations, press features or customer support — reach out to us directly.
            </p>

            <div className="space-y-6">
              {[
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25H4.5A2.25 2.25 0 0 1 2.25 17.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0-10.5 6.75L2.25 6.75" />
                    </svg>
                  ),
                  label: "Email",
                  value: BRAND.email,
                },
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/>
                    </svg>
                  ),
                  label: "Instagram",
                  value: BRAND.instagram,
                },
                {
                  icon: (
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                  ),
                  label: "Twitter / X",
                  value: BRAND.twitter,
                },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-5">
                  <div className="w-12 h-12 border border-red-700/50 flex items-center justify-center text-red-500 flex-shrink-0">
                    {item.icon}
                  </div>
                  <div>
                    <p className="text-gray-600 text-xs font-['Inter'] tracking-widest uppercase mb-0.5">{item.label}</p>
                    <p className="text-white font-['Inter'] text-sm">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — Contact form */}
          <div className="bg-[#0d0d0d] border border-white/5 p-10">
            <h3 className="text-white font-['Playfair_Display'] text-2xl font-bold mb-8">Send a Message</h3>
            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase block mb-2">First Name</label>
                  <input
                    type="text"
                    placeholder="John"
                    className="w-full bg-black border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3.5 outline-none transition-colors duration-300 placeholder:text-gray-700"
                  />
                </div>
                <div>
                  <label className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase block mb-2">Last Name</label>
                  <input
                    type="text"
                    placeholder="Doe"
                    className="w-full bg-black border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3.5 outline-none transition-colors duration-300 placeholder:text-gray-700"
                  />
                </div>
              </div>
              <div>
                <label className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase block mb-2">Email</label>
                <input
                  type="email"
                  placeholder="john@example.com"
                  className="w-full bg-black border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3.5 outline-none transition-colors duration-300 placeholder:text-gray-700"
                />
              </div>
              <div>
                <label className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase block mb-2">Subject</label>
                <input
                  type="text"
                  placeholder="Order inquiry / Collaboration"
                  className="w-full bg-black border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3.5 outline-none transition-colors duration-300 placeholder:text-gray-700"
                />
              </div>
              <div>
                <label className="text-gray-500 text-xs font-['Inter'] tracking-widest uppercase block mb-2">Message</label>
                <textarea
                  rows={5}
                  placeholder="Your message..."
                  className="w-full bg-black border border-white/10 focus:border-red-600 text-white font-['Inter'] text-sm px-4 py-3.5 outline-none transition-colors duration-300 placeholder:text-gray-700 resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-red-600 hover:bg-red-700 text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase py-4 transition-colors duration-300"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
