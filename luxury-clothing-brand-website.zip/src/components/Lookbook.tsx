import { LOOKBOOK } from "../config/siteConfig";

export default function Lookbook() {
  return (
    <section id="lookbook" className="bg-black py-28 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-red-500 text-xs font-['Inter'] font-semibold tracking-[0.5em] uppercase mb-4">
            Visual Stories
          </p>
          <h2 className="font-['Bebas_Neue'] text-[clamp(3rem,7vw,6rem)] text-white tracking-wide leading-none mb-6">
            LOOKBOOK
          </h2>
          <div className="flex items-center justify-center gap-4">
            <div className="h-px w-16 bg-red-700" />
            <div className="w-2 h-2 bg-red-600 rotate-45" />
            <div className="h-px w-16 bg-red-700" />
          </div>
        </div>

        {/* Masonry-style grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {LOOKBOOK.map((item, index) => (
            <div
              key={item.id}
              className={`relative overflow-hidden group cursor-pointer ${
                index === 0 ? "lg:row-span-2" : ""
              }`}
              style={{ aspectRatio: index === 0 ? "3/4" : "3/4" }}
            >
              <img
                src={item.image}
                alt={item.label}
                className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-110"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              {/* Red side bar */}
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              {/* Label */}
              <div className="absolute bottom-0 left-0 right-0 p-5 translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-500">
                <p className="text-red-500 text-[10px] font-['Inter'] font-bold tracking-[0.4em] uppercase mb-1">
                  Velocity
                </p>
                <p className="text-white font-['Bebas_Neue'] text-xl tracking-widest">
                  {item.label}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-500 font-['Inter'] text-sm mb-6">
            Follow us for daily drops and behind-the-scenes content
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-3 text-white font-['Inter'] font-semibold text-xs tracking-widest uppercase border border-white/20 hover:border-red-600 px-10 py-4 transition-all duration-300 hover:bg-red-600/10"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z"/>
            </svg>
            Follow @velocitybrand
          </a>
        </div>
      </div>
    </section>
  );
}
