// ============================================================
//  VELOCITY — SITE CONFIGURATION
//  Edit this file to update products, prices, images & text.
// ============================================================

export const BRAND = {
  name: "VELOCITY",
  tagline: "BEYOND FASHION. BEYOND LIMITS.",
  description:
    "Born from the streets. Built for the elite. Velocity is a luxury streetwear brand crafted for those who move fast and look sharp.",
  email: "contact@velocitybrand.com",
  instagram: "@velocitybrand",
  twitter: "@velocitybrand",
};

// ─── HERO SECTION ────────────────────────────────────────────
export const HERO = {
  // Replace with your own image URL or a path like "/images/hero.jpg"
  backgroundImage: "/images/hero-bg.jpg",
  heading: "DEFINE YOUR\nVELOCITY",
  subheading: "New Collection — 2025",
  ctaText: "Shop Now",
  ctaLink: "#products",
};

// ─── ANNOUNCEMENT BAR ────────────────────────────────────────
export const ANNOUNCEMENT = {
  text: "🔥 FREE SHIPPING ON ORDERS OVER $150  ·  NEW COLLECTION DROPPING SOON  ·  USE CODE: VELOCITY10 FOR 10% OFF",
};

// ─── PRODUCTS ────────────────────────────────────────────────
// To change a product image: replace the `image` URL with your own.
// To change price: update the `price` field (number in USD).
// To add a product: copy a product block and add it to the array.
export const PRODUCTS = [
  {
    id: 1,
    name: "Velocity Signature Hoodie",
    category: "Hoodies",
    price: 189,
    originalPrice: 240,
    badge: "BESTSELLER",
    badgeColor: "red",
    description: "Premium heavyweight cotton blend with embroidered logo. Oversized fit.",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Crimson"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/17043219/pexels-photo-17043219.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: true,
  },
  {
    id: 2,
    name: "Shadow Cargo Pants",
    category: "Bottoms",
    price: 215,
    originalPrice: null,
    badge: "NEW",
    badgeColor: "red",
    description: "Technical cargo pants with matte finish and hidden zip pockets.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/21967302/pexels-photo-21967302.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: true,
  },
  {
    id: 3,
    name: "Apex Bomber Jacket",
    category: "Outerwear",
    price: 349,
    originalPrice: 420,
    badge: "SALE",
    badgeColor: "gold",
    description: "Sleek bomber in satin-finish shell with contrast interior lining.",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Midnight Red"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/12774216/pexels-photo-12774216.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: true,
  },
  {
    id: 4,
    name: "Stealth Crewneck",
    category: "Tops",
    price: 159,
    originalPrice: null,
    badge: null,
    badgeColor: null,
    description: "Ultra-soft fleece crewneck with tonal embroidery detailing.",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/29996214/pexels-photo-29996214.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: true,
  },
  {
    id: 5,
    name: "V-Logo Tee",
    category: "Tops",
    price: 89,
    originalPrice: null,
    badge: "LIMITED",
    badgeColor: "red",
    description: "Heavyweight cotton tee with oversized V-Logo print on chest.",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Red"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/35495785/pexels-photo-35495785.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: true,
  },
  {
    id: 6,
    name: "Phantom Tracksuit",
    category: "Sets",
    price: 299,
    originalPrice: 360,
    badge: "SET",
    badgeColor: "red",
    description: "Matching jacket and jogger set in moisture-wicking performance fabric.",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black"],
    // ↓ Replace this URL with your product photo
    image: "https://images.pexels.com/photos/1437796/pexels-photo-1437796.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=600",
    inStock: false,
  },
];

// ─── CATEGORIES ──────────────────────────────────────────────
export const CATEGORIES = ["All", "Hoodies", "Tops", "Bottoms", "Outerwear", "Sets"];

// ─── LOOKBOOK / GALLERY ──────────────────────────────────────
// Replace image URLs with your own lookbook photos
export const LOOKBOOK = [
  {
    id: 1,
    image: "https://images.pexels.com/photos/21967304/pexels-photo-21967304.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    label: "AUTUMN EDIT",
  },
  {
    id: 2,
    image: "https://images.pexels.com/photos/36976939/pexels-photo-36976939.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    label: "NIGHT SERIES",
  },
  {
    id: 3,
    image: "https://images.pexels.com/photos/29538558/pexels-photo-29538558.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    label: "STREET READY",
  },
  {
    id: 4,
    image: "https://images.pexels.com/photos/19887010/pexels-photo-19887010.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=700",
    label: "CORE COLLECTION",
  },
];

// ─── FEATURES / USPs ─────────────────────────────────────────
export const FEATURES = [
  { icon: "🖤", title: "Premium Fabrics", desc: "Sourced from the world's finest mills." },
  { icon: "⚡", title: "Fast Delivery", desc: "Express shipping worldwide in 3–5 days." },
  { icon: "🔒", title: "Secure Payment", desc: "100% encrypted & safe checkout." },
  { icon: "↩️", title: "Easy Returns", desc: "30-day hassle-free return policy." },
];

// ─── TESTIMONIALS ────────────────────────────────────────────
export const TESTIMONIALS = [
  {
    id: 1,
    name: "Jordan M.",
    handle: "@jordanwears",
    text: "Velocity dropped and I literally can't wear anything else. The hoodie quality is insane — thick, warm and the logo hits perfectly.",
    rating: 5,
    avatar: "JM",
  },
  {
    id: 2,
    name: "Aria S.",
    handle: "@aria.styles",
    text: "Finally a brand that matches luxury with street. The bomber jacket is my most complimented piece this season.",
    rating: 5,
    avatar: "AS",
  },
  {
    id: 3,
    name: "Marcus K.",
    handle: "@mkfashion",
    text: "Packaging alone sets the standard. The tracksuit fits perfectly and the fabric feels premium on every level.",
    rating: 5,
    avatar: "MK",
  },
];
