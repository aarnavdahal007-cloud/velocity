# VELOCITY — Luxury Clothing Brand Website

A luxury streetwear brand website built with **React + Vite + Tailwind CSS**.  
Theme: **Black & Red**

---

## 🚀 GitHub Pages Deployment

### 1. Clone or fork this repo

```bash
git clone https://github.com/YOUR_USERNAME/velocity-brand.git
cd velocity-brand
npm install
```

### 2. Install dependencies & run locally

```bash
npm install
npm run dev
```

### 3. Deploy to GitHub Pages

Install the `gh-pages` package:

```bash
npm install -D gh-pages
```

In `package.json`, add these fields:

```json
"homepage": "https://YOUR_USERNAME.github.io/velocity-brand",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}
```

Then deploy:

```bash
npm run deploy
```

Your site will be live at `https://YOUR_USERNAME.github.io/velocity-brand`

---

## ✏️ How to Customize

All content is controlled in one file:

```
src/config/siteConfig.ts
```

### Change Product Photos

Open `siteConfig.ts` and find the `PRODUCTS` array. Each product has an `image` field:

```ts
image: "https://your-image-url.com/photo.jpg",
// OR use a local file:
image: "/images/your-product.jpg",  // put image in public/images/
```

### Change Prices

Find the product and update the `price` field:

```ts
price: 189,           // current price
originalPrice: 240,   // crossed-out original (set to null to hide)
```

### Add a New Product

Copy any product block in the `PRODUCTS` array and customize:

```ts
{
  id: 7,                            // unique ID
  name: "New Product Name",
  category: "Hoodies",              // must match a category in CATEGORIES
  price: 120,
  originalPrice: null,              // or a number like 150
  badge: "NEW",                     // or null
  badgeColor: "red",                // "red", "gold", or null
  description: "Product description here.",
  sizes: ["S", "M", "L", "XL"],
  colors: ["Black"],
  image: "https://your-image-url.com/photo.jpg",
  inStock: true,
},
```

### Change Brand Info

Update the `BRAND` object at the top of `siteConfig.ts`:

```ts
export const BRAND = {
  name: "VELOCITY",
  tagline: "YOUR TAGLINE HERE",
  description: "Your brand story...",
  email: "your@email.com",
  instagram: "@yourhandle",
  twitter: "@yourhandle",
};
```

### Change Hero Section

Update the `HERO` object:

```ts
export const HERO = {
  backgroundImage: "/images/your-hero.jpg", // drop image in public/images/
  heading: "YOUR\nHEADING",
  subheading: "Season 2025",
  ctaText: "Shop Now",
  ctaLink: "#products",
};
```

### Update Lookbook Photos

Edit the `LOOKBOOK` array — replace each `image` URL with your own.

---

## 📁 File Structure

```
velocity-brand/
├── public/
│   └── images/          ← Place your custom images here
├── src/
│   ├── config/
│   │   └── siteConfig.ts   ← ⭐ MAIN CONFIG FILE (edit prices, photos, text)
│   ├── components/
│   │   ├── AnnouncementBar.tsx
│   │   ├── Navbar.tsx
│   │   ├── Hero.tsx
│   │   ├── Features.tsx
│   │   ├── Products.tsx
│   │   ├── Lookbook.tsx
│   │   ├── About.tsx
│   │   ├── Testimonials.tsx
│   │   ├── Newsletter.tsx
│   │   ├── Contact.tsx
│   │   └── Footer.tsx
│   ├── App.tsx
│   └── index.css
├── index.html
└── package.json
```

---

## 🛠️ Tech Stack

- React 18
- Vite
- Tailwind CSS v4
- TypeScript
- Google Fonts (Bebas Neue, Playfair Display, Inter)

---

*© 2025 VELOCITY. All rights reserved.*
